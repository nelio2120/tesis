package com.example.myapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.API.API;
import com.example.myapplication.API.Services.Service;
import com.example.myapplication.Adapter.UsuarioAdapter;
import com.example.myapplication.R;
import com.example.myapplication.model.Persona;
import com.example.myapplication.model.Usuario;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UsuarioActivity extends AppCompatActivity {
    ListView lista;
    UsuarioAdapter adapter;
    List<Usuario> lista_usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);

        lista = (ListView)findViewById(R.id.listview_usuarios);
        //lista_usuario = new ArrayList<>();
        //Log.e("ERROR","Lista Usuario "+lista_usuario);

        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<List<Usuario>> data = serv.getUsuarios();
        data.enqueue(new Callback<List<Usuario>>() {
            @Override
            public void onResponse(Call<List<Usuario>> call, Response<List<Usuario>> response) {
                if (response.isSuccessful()){
                    lista_usuario = new ArrayList<>();
                    lista_usuario = response.body();
                    adapter = new UsuarioAdapter(UsuarioActivity.this,lista_usuario);
                    lista.setAdapter(adapter);
                    Log.e("ERROR","Lista Usuario "+lista_usuario);
                }
            }

            @Override
            public void onFailure(Call<List<Usuario>> call, Throwable t) {
                Log.e("Network Error: ",t.getLocalizedMessage());
                Log.e("Error",t.getMessage());
            }
        });



        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Usuario obj = lista_usuario.get(position);
            }
        });

    }

}