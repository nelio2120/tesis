package com.example.myapplication.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.API.API;
import com.example.myapplication.API.Services.Service;
import com.example.myapplication.Activity.RegistroActivity;
import com.example.myapplication.R;
import com.example.myapplication.model.Persona;
import com.example.myapplication.model.Rol;
import com.example.myapplication.model.Usuario;
import com.google.gson.GsonBuilder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UsuarioAdapter extends BaseAdapter {
    Context context;
    List<Usuario> usuarios;
    Persona persona_id;
    Rol rol_id;

    public UsuarioAdapter(Context context, List<Usuario> usuarios) {
        this.context = context;
        this.usuarios = usuarios;
    }

    @Override
    public int getCount() {
        return usuarios.size();
    }

    @Override
    public Object getItem(int position) {
        return usuarios.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context, R.layout.layout_item_usuario,null);
        TextView usuario = (TextView) view.findViewById(R.id.cedula_usu_item);
        TextView persona = (TextView) view.findViewById(R.id.apellido_usu_item);
        usuario.setText(usuarios.get(position).getNombre());
        Traer_persona(usuarios.get(position).getIdPersona(),persona);
        return view;
    }
    public void Traer_persona(int id,final TextView persona){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<Persona> data = serv.getPersona(id);
        data.enqueue(new Callback<Persona>() {
            @Override
            public void onResponse(Call<Persona> call, Response<Persona> response) {
                if (response.isSuccessful()){
                    Log.e("Persona","Persona"+response.body());
                    persona_id = response.body();
                    persona.setText(persona_id.getNombre() + " "+persona_id.getApellido());
                }
            }
            @Override
            public void onFailure(Call<Persona> call, Throwable t) {
                Log.e("Error","Ocurrio un error: "+ t.getMessage());
            }
        });
    }


    public void Traer_rol(int id){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<Rol> datos = serv.getRol(id);
        datos.enqueue(new Callback<Rol>() {
            @Override
            public void onResponse(Call<Rol> call, Response<Rol> response) {
                if (response.isSuccessful()){
                    rol_id = response.body();

                }
            }

            @Override
            public void onFailure(Call<Rol> call, Throwable t) {
                Log.e("Error","Ocurrio un error: "+ t.getMessage());
            }
        });

    }
}
