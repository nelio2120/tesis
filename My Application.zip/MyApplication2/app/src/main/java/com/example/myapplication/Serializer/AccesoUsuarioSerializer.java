package com.example.myapplication.Serializer;

import com.example.myapplication.model.AccesoUsuario;

import java.util.List;

public class AccesoUsuarioSerializer {
    private List<AccesoUsuario> acceso;

    public AccesoUsuarioSerializer(List<AccesoUsuario> acceso) {
        this.acceso = acceso;
    }

    public AccesoUsuarioSerializer() {
    }

    public List<AccesoUsuario> getAcceso() {
        return acceso;
    }

    public void setAcceso(List<AccesoUsuario> acceso) {
        this.acceso = acceso;
    }
}
