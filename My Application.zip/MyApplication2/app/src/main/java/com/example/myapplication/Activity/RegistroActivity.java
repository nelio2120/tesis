package com.example.myapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.API.API;
import com.example.myapplication.API.Services.Service;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.model.Persona;
import com.example.myapplication.model.Rol;
import com.example.myapplication.model.Usuario;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistroActivity extends AppCompatActivity {
    private Spinner spinner,spinnerpersona;
    EditText usuario,clave,confclave,correo;
    Button btn_registrar,salir;
    int rol,persona;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        Toast.makeText(RegistroActivity.this,"Bienvenido",Toast.LENGTH_LONG).show();
        Traer_persona();
        Traer_rol();

        usuario = (EditText) findViewById(R.id.editUsuario);
        clave = (EditText) findViewById(R.id.editClave);
        correo = (EditText) findViewById(R.id.editCorreo);
        confclave = (EditText) findViewById(R.id.editConfClave);
        btn_registrar = (Button) findViewById(R.id.btnRegistro);
        salir = (Button) findViewById(R.id.btn_salir);

        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });

        btn_registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Tag","PERSONA: "+persona);
                Log.e("Tag","Rol: "+rol);
                Usuario user = new Usuario();
                user.setIdUsuario(0);
                user.setNombre(usuario.getText().toString());
                user.setCorreo(correo.getText().toString());
                user.setPassword(clave.getText().toString());
                user.setIdPersona(persona);
                user.setIdRol(rol);
                if (clave.getText().toString().equals(confclave.getText().toString())){
                    guardar(user);
                }else{
                    Toast.makeText(RegistroActivity.this,"El nombre y la contra debe ser igual",Toast.LENGTH_LONG).show();
                }
            }
        });





    }
    public void guardar(Usuario usuario){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<Usuario> datos = serv.postUsuario(usuario);
        datos.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if (response.isSuccessful()){
                    Toast.makeText(RegistroActivity.this,"Registrado",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                Toast.makeText(RegistroActivity.this,"No Registrado, Error: "+ t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    public void Traer_rol(){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<List<Rol>> datos = serv.getRol();
        datos.enqueue(new Callback<List<Rol>>() {
            @Override
            public void onResponse(Call<List<Rol>> call, Response<List<Rol>> response) {
                if (response.isSuccessful()){
                    List<Rol> roles = response.body();
                    spinner = findViewById(R.id.rol);
                    ArrayAdapter<Rol> adapters = new ArrayAdapter<Rol>(RegistroActivity.this,
                            android.R.layout.simple_spinner_item, roles);
                    adapters.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapters);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            Rol rol = (Rol) parent.getSelectedItem();
                            displayRolData(rol);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                            Log.e("Error","Verificar conexion a internet");
                        }
                    });

                }
            }

            @Override
            public void onFailure(Call<List<Rol>> call, Throwable t) {
                Toast.makeText(RegistroActivity.this,"ERROR",Toast.LENGTH_LONG).show();
            }
        });
    }
    public void Traer_persona(){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<List<Persona>> data = serv.getPersona();
        data.enqueue(new Callback<List<Persona>>() {
            @Override
            public void onResponse(Call<List<Persona>> call, Response<List<Persona>> response) {
                if (response.isSuccessful()){
                    Log.e("My tag","Si entra: "+ response.body());
                    List<Persona> persona = response.body();
                    spinnerpersona = findViewById(R.id.spinPersona);
                    ArrayAdapter<Persona> adapters = new ArrayAdapter<Persona>(RegistroActivity.this,
                            android.R.layout.simple_spinner_item, persona);
                    adapters.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerpersona.setAdapter(adapters);
                    spinnerpersona.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            Persona persona = (Persona) parent.getSelectedItem();
                            displayPersonaData(persona);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                }
            }

            @Override
            public void onFailure(Call<List<Persona>> call, Throwable t) {
                Toast.makeText(RegistroActivity.this,"Error de Conexion a internet",Toast.LENGTH_LONG);

            }
        });
    }
    public void getSelectedRol(View view){
        Rol roles = (Rol) spinner.getSelectedItem();
        displayRolData(roles);
    }
    public void displayRolData(Rol rol){
        String name = rol.getNombre();
        int id = rol.getId();
        String data = "Name: "+name + " Id: "+id;
        this.rol = id;
        Toast.makeText(RegistroActivity.this,data,Toast.LENGTH_LONG).show();
    }
    public void displayPersonaData(Persona persona){
        String name = persona.getNombre();
        int id = persona.getIdPersona();
        String data = "Name: "+name + " Id: "+id;
        this.persona = id;
        Toast.makeText(RegistroActivity.this,data,Toast.LENGTH_LONG).show();
    }

}