package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.API.API;
import com.example.myapplication.API.Services.Service;
import com.example.myapplication.model.Usuario;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    EditText etUsuario,etPass;
    Button btn_iniciar,btn_salir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUsuario = (EditText)findViewById(R.id.txt_usuario);
        etPass = (EditText)findViewById(R.id.txt_pass);
        btn_iniciar = (Button) findViewById(R.id.btnRegistro);
        btn_salir = (Button)findViewById(R.id.btn_salir);

        btn_iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Usuario = etUsuario.getText().toString();
                String Clave = etPass.getText().toString();

                final GsonBuilder builder = new GsonBuilder().setLenient();
                API.retrofit = null;
                Service serv = API.getApi(builder).create(Service.class);
                Call<com.example.myapplication.model.Usuario> datos = serv.getUsuarios(Usuario,Clave);
                datos.enqueue(new Callback<com.example.myapplication.model.Usuario>() {
                    @Override
                    public void onResponse(Call<com.example.myapplication.model.Usuario> call, Response<com.example.myapplication.model.Usuario> response) {

                    }

                    @Override
                    public void onFailure(Call<com.example.myapplication.model.Usuario> call, Throwable t) {

                    }
                });
            }
        });

    }
}