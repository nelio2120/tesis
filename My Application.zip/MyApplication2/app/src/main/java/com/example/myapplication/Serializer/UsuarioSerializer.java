package com.example.myapplication.Serializer;

import com.example.myapplication.model.Usuario;

import java.util.List;

public class UsuarioSerializer {
    private List<Usuario> usuario;

    public UsuarioSerializer(List<Usuario> usuario) {
        this.usuario = usuario;
    }

    public UsuarioSerializer() {
    }

    public List<Usuario> getUsuario() {
        return usuario;
    }

    public void setUsuario(List<Usuario> usuario) {
        this.usuario = usuario;
    }
}
