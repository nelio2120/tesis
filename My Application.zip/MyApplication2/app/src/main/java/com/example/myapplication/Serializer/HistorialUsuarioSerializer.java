package com.example.myapplication.Serializer;

import com.example.myapplication.model.HistorialUsuario;

import java.util.List;

public class HistorialUsuarioSerializer {
    private List<HistorialUsuario> historial;

    public HistorialUsuarioSerializer(List<HistorialUsuario> historial) {
        this.historial = historial;
    }

    public HistorialUsuarioSerializer() {
    }

    public List<HistorialUsuario> getHistorial() {
        return historial;
    }

    public void setHistorial(List<HistorialUsuario> historial) {
        this.historial = historial;
    }
}
