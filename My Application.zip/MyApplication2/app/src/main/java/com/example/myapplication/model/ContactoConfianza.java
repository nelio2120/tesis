package com.example.myapplication.model;

import java.io.Serializable;
import java.util.ArrayList;

public class ContactoConfianza implements Serializable {
    private int id;
    private ArrayList<Integer> idPersona;
    private String Contacto1;
    private String Contacto2;

    public ContactoConfianza(int id,ArrayList<Integer> idPersona, String contacto1, String contacto2) {
        this.id = id;
        this.idPersona = idPersona;
        Contacto1 = contacto1;
        Contacto2 = contacto2;
    }

    public ContactoConfianza() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Integer> getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(ArrayList<Integer> idPersona) {
        this.idPersona = idPersona;
    }

    public String getContacto1() {
        return Contacto1;
    }

    public void setContacto1(String contacto1) {
        Contacto1 = contacto1;
    }

    public String getContacto2() {
        return Contacto2;
    }

    public void setContacto2(String contacto2) {
        Contacto2 = contacto2;
    }
}
