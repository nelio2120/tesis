package com.example.myapplication.Serializer;

import com.example.myapplication.model.ContactoConfianza;

import java.util.List;

public class ContactoConfianzaSerializer {
    private List<ContactoConfianza> contacto;

    public ContactoConfianzaSerializer(List<ContactoConfianza> contacto) {
        this.contacto = contacto;
    }

    public ContactoConfianzaSerializer() {
    }

    public List<ContactoConfianza> getContacto() {
        return contacto;
    }

    public void setContacto(List<ContactoConfianza> contacto) {
        this.contacto = contacto;
    }
}
