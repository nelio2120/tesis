package com.example.myapplication.API.Services;

import com.example.myapplication.model.AccesoUsuario;
import com.example.myapplication.model.ContactoConfianza;
import com.example.myapplication.model.HistorialUsuario;
import com.example.myapplication.model.Persona;
import com.example.myapplication.model.Rol;
import com.example.myapplication.model.Usuario;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Service {

    @GET("/Acceso_usuario/?format=json")
    Call<List<AccesoUsuario>> getAcceso();

    @GET("/Acceso_usuario/{id}/?format=json")
    Call <AccesoUsuario> getAcceso(@Path("id") int id);

    @GET("/Listar_usuario/?format=json")
    Call <List<Usuario>> getUsuarios();

    @GET("/Listar_usuario/?format=json")
    Call <Usuario> getUsuarios(@Query("usuario") String usuario, @Query("password") String password);

    @GET("/Listar_usuario/{id}/?format=json")
    Call <Usuario> getUsuarios(@Path("id") String id);

    @GET("/Listar_persona/?format=json")
    Call <List<Persona>> getPersona();

    @GET("/Listar_persona/?format=json")
    Call <Persona> getPersona(@Query("idPersona") int id);

    @GET("/Contacto_confianza/?format=json")
    Call <List<ContactoConfianza>> getConfianza();

    @GET("/Contacto_confianza/{id}/?format=json")
    Call <ContactoConfianza> getConfianza(@Path("id") int id);

    @GET("/Historial_usuario/?format=json")
    Call <List<HistorialUsuario>> getHistorial();

    @GET("/Historial_usuario/{id}/?format=json")
    Call <HistorialUsuario> getHistorial(@Path("id") int id);

    @GET("/Roles/?format=json")
    Call <List<Rol>> getRol();

    @GET("/Roles/{id}/?format=json")
    Call <Rol> getRol(@Path("id") int id);

    @POST("/Listar_usuario/")
    Call <Usuario> postUsuario(@Body Usuario usuario);

    @POST("/Listar_persona/?format=json")
    Call <Persona> postPersona(@Body Persona persona);

    @POST("/Historial_usuario/")

    Call <HistorialUsuario> postHistorial(@Body HistorialUsuario historialUsuario);












}
