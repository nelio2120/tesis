package com.example.myapplication.model;

import java.io.Serializable;

public class Persona implements Serializable {
    private Integer idPersona;
    private String nombre;
    private String apellido;
    private String cedula;
    private String fecha_nacimiento;
    private String estado;

    public Persona(Integer id, String nombre,String apellido, String cedula, String fecha, String estado) {
        this.idPersona = id;
        this.apellido = apellido;
        this.nombre = nombre;
        this.cedula = cedula;
        this.fecha_nacimiento = fecha;
        this.estado = estado;
    }

    public Persona() {
    }

    public Integer getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Integer idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return this.nombre + " " + this.apellido;
    }
}
