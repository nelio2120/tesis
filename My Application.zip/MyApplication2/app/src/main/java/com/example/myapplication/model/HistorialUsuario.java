package com.example.myapplication.model;

import java.io.Serializable;

public class HistorialUsuario implements Serializable {
    private int idHistoricoUsuario;
    private int idUsuario;
    private String lat;
    private String lon;
    private String fecha;
    private String estado;

    public HistorialUsuario(int idHistoricoUsuario, int idUsuario, String lat, String lon, String fecha, String estado) {
        this.idHistoricoUsuario = idHistoricoUsuario;
        this.idUsuario = idUsuario;
        this.lat = lat;
        this.lon = lon;
        this.fecha = fecha;
        this.estado = estado;
    }

    public HistorialUsuario() {
    }

    public int getIdHistoricoUsuario() {
        return idHistoricoUsuario;
    }

    public void setIdHistoricoUsuario(int idHistoricoUsuario) {
        this.idHistoricoUsuario = idHistoricoUsuario;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
