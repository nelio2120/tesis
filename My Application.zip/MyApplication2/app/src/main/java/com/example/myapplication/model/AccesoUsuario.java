package com.example.myapplication.model;

import java.io.Serializable;
import java.util.ArrayList;

public class AccesoUsuario implements Serializable {
    private int idUsuario;
    private ArrayList<Integer> idHistorico;

    public AccesoUsuario(int idUsuario, ArrayList<Integer> idHistorico) {
        this.idUsuario = idUsuario;
        this.idHistorico = idHistorico;
    }

    public AccesoUsuario() {
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public ArrayList<Integer> getIdHistorico() {
        return idHistorico;
    }

    public void setIdHistorico(ArrayList<Integer> idHistorico) {
        this.idHistorico = idHistorico;
    }
}
