package com.example.myapplication.Serializer;

import com.example.myapplication.model.Persona;

import java.util.List;

public class PersonaSerializer {
    private List<Persona> persona;

    public PersonaSerializer(List<Persona> persona) {
        this.persona = persona;
    }

    public PersonaSerializer() {
    }

    public List<Persona> getPersona() {
        return persona;
    }

    public void setPersona(List<Persona> persona) {
        this.persona = persona;
    }
}
