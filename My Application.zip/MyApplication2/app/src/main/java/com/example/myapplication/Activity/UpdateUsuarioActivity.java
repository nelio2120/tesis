package com.example.myapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myapplication.API.API;
import com.example.myapplication.API.Services.Service;
import com.example.myapplication.R;
import com.example.myapplication.model.Persona;
import com.example.myapplication.model.Rol;
import com.example.myapplication.model.Usuario;
import com.google.gson.GsonBuilder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateUsuarioActivity extends AppCompatActivity {
    private Spinner spinner,spinnerpersona;
    EditText usuario,clave,confclave,correo;
    Button btn_registrar,salir;
    int rol,persona;
    Usuario obj_usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_usuario);

        final Bundle bundle = getIntent().getExtras();
        obj_usuario = new Usuario();

        if (bundle != null){
            obj_usuario = (Usuario) bundle.getSerializable("usuarios");
        }

        usuario = (EditText) findViewById(R.id.editUsuario);
        clave = (EditText) findViewById(R.id.editClave);
        correo = (EditText) findViewById(R.id.editCorreo);
        confclave = (EditText) findViewById(R.id.editConfClave);
        btn_registrar = (Button) findViewById(R.id.btnRegistro);
        salir = (Button) findViewById(R.id.btn_salir);

        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });

        usuario.setText(obj_usuario.getNombre());
        clave.setText(obj_usuario.getPassword());
        correo.setText(obj_usuario.getCorreo());


    }
    public void Traer_rol(){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<List<Rol>> datos = serv.getRol();
        datos.enqueue(new Callback<List<Rol>>() {
            @Override
            public void onResponse(Call<List<Rol>> call, Response<List<Rol>> response) {
                if (response.isSuccessful()){
                    List<Rol> roles = response.body();
                    spinner = findViewById(R.id.rol);
                    ArrayAdapter<Rol> adapters = new ArrayAdapter<Rol>(UpdateUsuarioActivity.this,
                            android.R.layout.simple_spinner_item, roles);
                    adapters.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapters);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            Rol rol = (Rol) parent.getSelectedItem();
                            displayRolData(rol);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                            Log.e("Error","Verificar conexion a internet");
                        }
                    });

                }
            }

            @Override
            public void onFailure(Call<List<Rol>> call, Throwable t) {
                Toast.makeText(UpdateUsuarioActivity.this,"ERROR",Toast.LENGTH_LONG).show();
            }
        });


    }
    public void Traer_persona(){
        final GsonBuilder builder = new GsonBuilder().setLenient();
        API.retrofit = null;
        Service serv = API.getApi(builder).create(Service.class);
        Call<List<Persona>> data = serv.getPersona();
        data.enqueue(new Callback<List<Persona>>() {
            @Override
            public void onResponse(Call<List<Persona>> call, Response<List<Persona>> response) {
                if (response.isSuccessful()){
                    Log.e("My tag","Si entra: "+ response.body());

                    List<Persona> persona = response.body();
                    spinnerpersona = findViewById(R.id.spinPersona);
                    ArrayAdapter<Persona> adapters = new ArrayAdapter<Persona>(UpdateUsuarioActivity.this,
                            android.R.layout.simple_spinner_item, persona);
                    adapters.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerpersona.setAdapter(adapters);
                    spinnerpersona.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            Persona persona = (Persona) parent.getSelectedItem();
                            displayPersonaData(persona);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                }
            }

            @Override
            public void onFailure(Call<List<Persona>> call, Throwable t) {
                Toast.makeText(UpdateUsuarioActivity.this,"Error de Conexion a internet",Toast.LENGTH_LONG);

            }
        });
    }


    public void getSelectedRol(View view){
        Rol roles = (Rol) spinner.getSelectedItem();
        displayRolData(roles);
    }
    public void displayRolData(Rol rol){
        String name = rol.getNombre();
        int id = rol.getId();
        String data = "Name: "+name + " Id: "+id;
        this.rol = id;
        Toast.makeText(UpdateUsuarioActivity.this,data,Toast.LENGTH_LONG).show();
    }
    public void displayPersonaData(Persona persona){
        String name = persona.getNombre();
        int id = persona.getIdPersona();
        String data = "Name: "+name + " Id: "+id;
        this.persona = id;
        Toast.makeText(UpdateUsuarioActivity.this,data,Toast.LENGTH_LONG).show();
    }
}